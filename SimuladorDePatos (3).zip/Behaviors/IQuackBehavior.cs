
namespace SimuladorDePatos.Behaviors
{
    public interface IQuackBehavior
    {
        void Quack();
    }
}
