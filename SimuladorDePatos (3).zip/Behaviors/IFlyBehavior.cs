
namespace SimuladorDePatos.Behaviors
{
    public interface IFlyBehavior
    {
        void Fly();
    }
}
